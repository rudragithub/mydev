<?php 
session_destroy();
?>
